#!/bin/bash
startl=$(date +%s)
## Load config file
source /home/$USER/.local/config/animegrimoire.conf
# Simple script to assist bluray.sh as they're explicitly ask for separated subtitle
# this methodology is decided because we must validate whether BDs has valid subtitle or not
# to make sure file result will have valid subtitle
# Please make sure file name convention is following standard before running this script
# Example: "[GSK_kun] Kaguya-sama Love Is War 01 [BDRip 1920x1080 HEVC FLAC] [43246B70].mkv"
# needs to be renamed to "Kaguya-sama Love Is War - 01.mkv"
# to remove everything inside '[ ]' you can use a simple rename tool using:
# $ rename 's/\[.*?\]//o' *.mkv
# then you can just replace to whatever you see it's fit
# $ rename 's/ Kaguya/Kaguya/o' *.mkv
# this one above is a simple way to remove any spaces ' ' before "Kaguya"

if ! [ -x "$(command -v ffmpeg)" ]; then
  echo 'Error: ffmpeg is not found.' >&2
  exit 1
fi

# Follow the format, "Kaguya-sama Love Is War - 01.ass"
subtitle="$(echo "$1" | cut -f 1 -d '.').ass"

# Subtitle is mostly in 0:2 from english fansub. if you extract the wrong channel,
# change it here
ffmpeg -i "$filename" -map 0:2 -c copy "$subtitle"

## Exit process
endl=$(date +%s)
echo "This script was running for $((endl-startl)) seconds."
